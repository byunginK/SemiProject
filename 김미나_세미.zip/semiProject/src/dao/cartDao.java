package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import db.DBClose;
import db.DBConnection;
import dto.cartDto;

public class cartDao {
	
	private static cartDao dao = new cartDao();
	
	private cartDao() {
	}
	
	public static cartDao getInstance() {
		return dao;
	}
	
	public List<cartDto> getList(String id){
		String sql = " SELECT A.SEQ, A.ID, B.SEQ, B.P_NAME, B.P_PRICE, A.QTY " + 
				" FROM FIVE_CART A " + 
				" JOIN FIVE_CATEGORY B ON A.ITEM_SEQ = B.SEQ " + 
				" WHERE A.ID= ? ";
		
		List<cartDto> list = new ArrayList<>();
		Connection conn = null;
        PreparedStatement psmt = null;
        ResultSet rs = null;
		
        try {
			conn = DBConnection.getConnection();
			psmt = conn.prepareStatement(sql);
			System.out.println("1/9 getList success");
			
			psmt.setString(1, id);
			
			rs = psmt.executeQuery();
			System.out.println("2/9 getList success");
			
			while(rs.next()) {
				int i=1;
				int seq = rs.getInt(i++);
				String sid = rs.getString(i++);
				int item_seq = rs.getInt(i++);
				String item_name = rs.getString(i++);
				int item_price =rs.getInt(i++);
				int qty = rs.getInt(i++);
				
				cartDto dto = new cartDto(seq,sid,item_seq,item_name,item_price,qty);
				list.add(dto);
			}
			System.out.println("3/9 getList success");
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBClose.close(psmt, conn, rs);
		}
		return list;
	}
	
}
