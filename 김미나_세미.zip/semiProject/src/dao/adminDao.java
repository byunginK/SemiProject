package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import db.DBClose;
import db.DBConnection;
import dto.blistDto;

public class adminDao {
	
	private static adminDao dao = new adminDao();
	
	private adminDao() {
	}
	
	public static adminDao getInstance() {
		return dao;
	}
	
	public List<blistDto> getQnaList(){
		String sql = " SELECT SEQ, ID, TITLE, UDATE  FROM FIVE_QNA ORDER BY SEQ DESC";
		
		List<blistDto> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		try {
			conn = DBConnection.getConnection();
			psmt = conn.prepareStatement(sql);
			System.out.println("1/9 admin getQnaList success ");
			
			rs = psmt.executeQuery();
			System.out.println("2/9 admin getQnaList success ");
			
			while(rs.next()) {
				int i=1;
				int seq = rs.getInt(i++);
				String id = rs.getString(i++);
				String title = rs.getString(i++);
				String udate = rs.getString(i++);
				
				blistDto dto = new blistDto(seq,id,title,udate);
				list.add(dto);
			}
			System.out.println("3/9 admin getQnaList success ");
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBClose.close(psmt, conn, rs);
		}
		return list;
	}
	
	public List<blistDto> getQnaList(int pageNumber){
		String sql = "  SELECT SEQ, ID, TITLE, UDATE " + 
				" FROM " + 
				" ( SELECT ROW_NUMBER()OVER(ORDER BY WDATE DESC) AS RNUM, " + 
				"	SEQ, ID, TITLE, UDATE  " + 
				" FROM FIVE_QNA  " + 
				" ORDER BY SEQ DESC " + 
				" ) " + 
				" WHERE ? <= RNUM AND RNUM <= ?" + 
				" ORDER BY SEQ DESC";
		
		List<blistDto> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		try {
			conn = DBConnection.getConnection();
			psmt = conn.prepareStatement(sql);
			System.out.println("1/9 admin getQnaList(num) success ");
			
			psmt.setInt(1, (pageNumber*10)+1);
			psmt.setInt(2, (pageNumber*10)+10);
			
			rs = psmt.executeQuery();
			System.out.println("2/9 admin getQnaList(num) success ");
			
			while(rs.next()) {
				int i=1;
				int seq = rs.getInt(i++);
				String id = rs.getString(i++);
				String title = rs.getString(i++);
				String udate = rs.getString(i++);
				
				blistDto dto = new blistDto(seq,id,title,udate);
				list.add(dto);
			}
			System.out.println("3/9 admin getQnaList(num) success ");
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBClose.close(psmt, conn, rs);
		}
		return list;
	}
	
	public List<blistDto> getQnaList(String need, String fneed,int pageNumber){
		String sql = "  SELECT SEQ, ID, TITLE, UDATE " + 
				" FROM " + 
				" ( SELECT ROW_NUMBER()OVER(ORDER BY WDATE DESC) AS RNUM, " + 
				"	SEQ, ID, TITLE, UDATE  " + 
				" FROM FIVE_QNA  "
				+ " WHERE "+need +" LIKE ? " + 
				" ORDER BY SEQ DESC " + 
				" ) " + 
				" WHERE ? <= RNUM AND RNUM <= ?" + 
				" ORDER BY SEQ DESC";
		
		List<blistDto> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		try {
			conn = DBConnection.getConnection();
			psmt = conn.prepareStatement(sql);
			System.out.println("1/9 admin getQnaList(all) success ");
			
			psmt.setString(1, "%"+fneed+"%");
			psmt.setInt(2, (pageNumber*10)+1);
			psmt.setInt(3, (pageNumber*10)+10);
			
			rs = psmt.executeQuery();
			System.out.println("2/9 admin getQnaList(all) success ");
			
			while(rs.next()) {
				int i=1;
				int seq = rs.getInt(i++);
				String id = rs.getString(i++);
				String title = rs.getString(i++);
				if(title.length() > 10) {
					title = title.substring(0,11);
					title += "...";
				}
				String udate = rs.getString(i++);
				
				blistDto dto = new blistDto(seq,id,title,udate);
				list.add(dto);
			}
			System.out.println("3/9 admin getQnaList(all) success ");
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBClose.close(psmt, conn, rs);
		}
		return list;
	}
	
	public int getQnaLen(){
		String sql = " SELECT COUNT(*) FROM FIVE_QNA ";
		
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		int len = 0;
		
		try {
			conn = DBConnection.getConnection();
			psmt = conn.prepareStatement(sql);
			System.out.println("1/9 admin getQnaLen success ");
			
			rs = psmt.executeQuery();
			System.out.println("2/9 admin getQnaLen success ");
			
			if(rs.next()) len = rs.getInt(1);
			System.out.println("3/9 admin getQnaLen success ");
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBClose.close(psmt, conn, rs);
		}
		return len;
	}
	
	public int getQnaLen(String need, String fneed){
		String sql = " SELECT COUNT(*) FROM FIVE_QNA ";
		
		//System.out.println("need = "+need);
		if(!need.equals("") && need != null) {
			sql += " WHERE "+need+" LIKE ? ";
		}
		
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		int len = 0;
		
		try {
			conn = DBConnection.getConnection();
			psmt = conn.prepareStatement(sql);
			
			if(!need.equals("") && need != null) {
				psmt.setString(1, "%"+fneed+"%");
			}
			//System.out.println("sql = "+sql);
			rs = psmt.executeQuery();
			System.out.println("2/9 admin getQnaLen(2) success ");
			
			if(rs.next()) len = rs.getInt(1);
			System.out.println("3/9 admin getQnaLen(2) success ");
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBClose.close(psmt, conn, rs);
		}
		return len;
	}
}
