package util;

import java.util.List;

import dao.calendarDao;
import dto.calendarDto;

public class calUtil {
	
    public static String getcalList(int year,int month,int startday, int lastday){
        String ym = year+getTwo(month);
        String str ="";

        str += "<table id='caltb'> " +
                "    <col width='150'><col width='150'><col width='150'><col width='150'><col width='150'>" +
                "    <col width='150'><col width='150'><col width='150'>" +
                "    <tr> " +
                "        <td><a href='cal_main.jsp?year="+(year-1)+"&month="+month+"'> << </a></td>" +
                "        <td><a href='cal_main.jsp?year="+year+"&month="+(month-1)+"'> < </a></td>" +
                "        <td colspan='3'>"+year+"년 "+getTwo(month+1)+"월</td>" +
                "        <td><a href='cal_main.jsp?year="+year+"&month="+(month+1)+"'> > </a></td>" +
                "        <td><a href='cal_main.jsp?year="+(year+1)+"&month="+month+"'> >> </a></td>" +
                "    </tr>" +
                "    <tr>" +
                "        <th>일</th><th>월</th><th>화</th><th>수</th>" +
                "        <th>목</th><th>금</th><th>토</th>" +
                "    </tr>";

        str +="<tr>";
        for(int i=1; i<startday; i++){
            str +="<td> </td>";
        }
        int date = 1;
        for(int i=0; i<lastday; i++){
            str+=getList(ym,date);
            if( ((date+startday-1)%7) == 0 ){
                str+="</tr><tr>";
            }
            date++;
        }

        for(int i=0; i<(7-(startday+lastday-1)%7); i++){
            str+="<td> </td></tr>";
        }
        str+="</table>";
        return str;
    }

    public static String getList(String ym, int date) {
        calendarDao dao = calendarDao.getInstance();
        List<calendarDto> list = dao.getdeList(ym);
        String str ="";
        int count = 0;
        String totd = ym+getTwo(date);
        str+="<td onclick='popfunc("+ym+getTwo(date)+")'><table><tr><th>"+getTwo(date) + "</th></tr>";
        str+="<tr><td><ul style='list-style-type:none;'>";
        for(int i=0; i<list.size(); i++){
            if(list.get(i).getCdate().equals(totd) ){
                count++;
                str+="<li>"+getShort(list.get(i).getContents())+"</li>";
            }
            if(count>4){
                break;
            }
        }
        str +="</ul></td></tr></table></td>";

        return str;
    }
    public static String getTwo(int n){
    	String num = n+"";
        return (num.length()<2)?"0"+num:num+"";
    }

    public static String getShort(String str){
        if(str.length()>5){
            str = str.substring(0,5);
            str +="...";
        }
        return str;
    }
	
}









