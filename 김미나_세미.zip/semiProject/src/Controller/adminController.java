package Controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.adminDao;
import dto.blistDto;
import net.sf.json.JSONObject;

@WebServlet("/admincont")
public class adminController extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("doGet");
		req.setCharacterEncoding("UTF-8");
		
		JSONObject obj = new JSONObject();
		String work = req.getParameter("work");
		
		if(work.equals("moveQnadel")) {
			String spageNumber = (req.getParameter("pageNumber")==null)?"0":req.getParameter("pageNumber");
			int pageNumber = Integer.parseInt(spageNumber);
			
			//System.out.println("controller page = "+pageNumber);
			adminDao dao = adminDao.getInstance();
			List<blistDto> list = dao.getQnaList(pageNumber); // 0 pageNumber 찾기
			int len = dao.getQnaLen();
			
			req.setAttribute("list", list);
			req.setAttribute("len", len);
			req.setAttribute("need", "");
			req.setAttribute("fneed", "");
			req.setAttribute("pageNumber", pageNumber);
			forward("./admin/admin_qna_delete.jsp",req,resp);
		}else if(work.equals("qsearch")) {
			String need = req.getParameter("need");
			String fneed = req.getParameter("fneed");
			String spage = req.getParameter("pageNumber");
			int pageNumber = Integer.parseInt(spage);
			
			adminDao dao = adminDao.getInstance();
			List<blistDto> list =dao.getQnaList(need, fneed, pageNumber);
			int len = dao.getQnaLen(need, fneed);
			
			//System.out.println("check = "+ list.toString());
			req.setAttribute("list", list);
			req.setAttribute("len", len);
			req.setAttribute("need", "");
			req.setAttribute("fneed", "");
			req.setAttribute("pageNumber", pageNumber);
			forward("./admin/admin_qna_delete.jsp",req,resp);
		}
		
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("doPost");
	}
	
	public void forward(String link,HttpServletRequest req, HttpServletResponse resp) {
		RequestDispatcher dispatcher = req.getRequestDispatcher(link);
		try {
			dispatcher.forward(req, resp);
		} catch (ServletException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
