package dto;

import java.io.Serializable;

public class CartDto implements Serializable {

	private int seq;
	private String id;
	private int item_seq;
	private int qty;
	private String color;
	private String item_size;
	private String p_name;
	private int price;
	private String filename;
	
	public CartDto() {
	}

	public CartDto(int seq, String id, int item_seq, int qty, String color, String item_size, String p_name, int price,
			String filename) {
		super();
		this.seq = seq;
		this.id = id;
		this.item_seq = item_seq;
		this.qty = qty;
		this.color = color;
		this.item_size = item_size;
		this.p_name = p_name;
		this.price = price;
		this.filename = filename;
	}

	public CartDto(String id, int item_seq, int qty, String color, String item_size, String p_name, int price,
			String filename) {
		super();
		this.id = id;
		this.item_seq = item_seq;
		this.qty = qty;
		this.color = color;
		this.item_size = item_size;
		this.p_name = p_name;
		this.price = price;
		this.filename = filename;
	}

	public int getSeq() {
		return seq;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getItem_seq() {
		return item_seq;
	}

	public void setItem_seq(int item_seq) {
		this.item_seq = item_seq;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getItem_size() {
		return item_size;
	}

	public void setItem_size(String item_size) {
		this.item_size = item_size;
	}

	public String getP_name() {
		return p_name;
	}

	public void setP_name(String p_name) {
		this.p_name = p_name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	@Override
	public String toString() {
		return "CartDto [seq=" + seq + ", id=" + id + ", item_seq=" + item_seq + ", qty=" + qty + ", color=" + color
				+ ", item_size=" + item_size + ", p_name=" + p_name + ", price=" + price + ", filename=" + filename
				+ "]";
	}

	
}
